All Machining Styles in the Styles folder (and subfolders) are automatically loaded into Alphacam.
